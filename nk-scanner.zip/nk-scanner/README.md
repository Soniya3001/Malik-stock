# NK Amritwani Live Trade Analyzer

Live NSE/BSE stock analyzer with 20 NK Amritwani rules + 8 Volume signals.

## Features
- **Live prices** via Twelve Data API
- **20 NK Amritwani rules** — Triveni Sangam, BB Blast, ORB, VWAP, 200 EMA, etc.
- **8 Volume signals** — OBV, MFI, AD Line, VSA, Volume Ratio, etc.
- **Self-calculated indicators** — SMA 5/9/20, EMA 200, RSI, Bollinger Bands, Pivot levels
- **Entry zone, Stop Loss, 3 Targets, Trailing SL**
- **IndexedDB** — Watchlist + History saved locally in browser
- **Auto-refresh** when market is live (9:15 AM - 3:30 PM IST)

## Setup

### 1. Get API Keys (Both Free)
- **Twelve Data**: [twelvedata.com](https://twelvedata.com) → Sign Up → Free (800 calls/day)
- **Gemini**: [aistudio.google.com](https://aistudio.google.com) → Get API Key → **Bilkul Free!**

### 2. Install & Run Locally
```bash
npm install
npm run dev
```
Open: http://localhost:5173

### 3. Deploy to GitHub Pages

1. Push this code to GitHub
2. Go to repo Settings → Pages → Source: **GitHub Actions**
3. Push to `main` branch → auto-deploys!

Your app will be live at: `https://YOUR_USERNAME.github.io/nk-scanner`

## How to Use
1. Enter **Twelve Data API key** → Save (twelvedata.com se free lo)
2. Enter **Gemini API key** → Save (aistudio.google.com se free lo)
3. Type stock symbol (RELIANCE, TCS, HDFCBANK...) → **SCAN**
4. Get live price + full NK Amritwani analysis with Gemini Flash 2.5
